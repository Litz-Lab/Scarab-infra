#!/bin/bash

app_cmd="DarwinStreamingServer -d"
# test_cmd="& sleep 3 && StreamingLoadTool -f /etc/streaming/streamingloadtool.conf"
test_cmd=""
trace_params="-trace_after_instrs 17M -exit_after_tracing 5M -verbose 1"
scarab_params="--frontend memtrace --inst_limit 999900"
collect_traces=" \
cd /home/memtrace/traces \
&& /home/memtrace/scarab/src/deps/dynamorio/build/bin64/drrun \
-t drcachesim -offline -outdir . $trace_params -- $app_cmd $test_cmd \
"
convert_traces=" \
cd /home/memtrace/traces \
&& bash /home/memtrace/scarab/utils/memtrace/run_portabilize_trace.sh \
&& read TRACEDIR < <(ls) \
"
run_scarab=" \
cd /home/memtrace/exp \
&& /home/memtrace/scarab/src/scarab \
--cbp_trace_r0=/home/memtrace/traces/\$TRACEDIR/trace \
--memtrace_modules_log=/home/memtrace/traces/\$TRACEDIR/raw \
$scarab_params \
"
# docker_cmd="$collect_traces && $convert_traces && $run_scarab"
docker_cmd="$collect_traces && $convert_traces"

docker build --no-cache -f dss/Dockerfile -t dss -- .
echo \
docker run --name dss -- dss bash -c "$docker_cmd"
docker run --name dss -- dss bash -c "$docker_cmd"
docker cp dss:/home/memtrace/traces ./traces
# docker cp dss:/home/memtrace/exp ./exp
docker container rm dss
